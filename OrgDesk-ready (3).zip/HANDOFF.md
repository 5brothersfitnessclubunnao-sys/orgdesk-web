# >>> START HERE — current status (updated 2026-11-16 ~07:50 IST)

## Who the owner is / how to talk to them
Owner runs "5 Brother's Fitness Club" (gym, Unnao). They are building OrgDesk to SELL to other organisations (gym/school/college). They write Hinglish, work mostly from an **Android phone** (screenshots are phone Chrome), and are not a developer. **Give ONE small step at a time, plain words, wait for "ho gaya" / a screenshot before the next step.** They want professional output, no unrequested files, and honest limits. Deploy method: GitHub web "Upload files" + GitHub Pages (no build tools). Do not touch their old 5 Brother's repo/Firebase — OrgDesk is a separate repo + separate Firebase project.

## What exists (Phase 1 is BUILT and tested on a mock Firebase, not yet on the real one)
All code is in `OrgDesk-phase1.zip` / `OrgDesk-ready.zip` (see file table below). **A new AI must get these files from the owner (ask them to attach the zip in the new chat) — they are not stored anywhere else.**

## Firebase setup progress (project `orgdesk`, id `orgdesk-fc207`)
- [x] Step 1 project created
- [x] Step 2 Authentication → Email/Password enabled (Google provider was cancelled; "Email link/passwordless" should be OFF — ask owner to confirm it shows only Email/Password Enabled)
- [x] Step 3 Firestore created (production mode, region asia-south1/Mumbai)
- [x] Step 4 rules from `firestore.rules` pasted and published (owner said done; verify no red error if problems appear)
- [x] Step 5 Web app registered; config received by screenshot and written into `firebase-config.js` (apiKey characters read from a screenshot — if sign-up shows "api-key-not-valid", re-check apiKey O/0 and I/l)
```
projectId: orgdesk-fc207   authDomain: orgdesk-fc207.firebaseapp.com
storageBucket: orgdesk-fc207.firebasestorage.app   messagingSenderId: 677150519977
appId: 1:677150519977:web:74de5f488494280d352fb8
```
- [ ] **Step 6 (NEXT)** get the files ready on the phone: download `OrgDesk-ready.zip` (already contains the correct `firebase-config.js`), extract with the Files app.
- [ ] Step 7 create a NEW public GitHub repo (e.g. `orgdesk`), Add file → Upload files → upload all extracted files (not the `t` folder), commit.
- [ ] Step 8 GitHub repo Settings → Pages → branch `main` / root → Save; wait for the URL.
- [ ] Step 9 Firebase → Authentication → Settings → **Authorized domains** → add `<githubusername>.github.io`.
- [ ] Step 10 open `https://<user>.github.io/orgdesk/setup.html`, run the wizard for a test gym, then `admin.html` login, submit a test admission via `join.html?o=<org-id>`, approve it, view the receipt, open the card link.
- After that: fix whatever breaks on the real Firebase, then Phase 2.

## Requirements captured after Phase 1 (to build in Phase 2/3)
- Attendance layers per person: selfie+GPS (regular), personal QR (VIP/senior staff — QR must hold an unguessable token, scanned only by a signed-in staff device), manual by admin.
- Staff entry gets "Attendance with QR": downloadable small ID card (name, organisation, post, department, floor, contact, blood group, QR). Bulk-download all members'/staff QRs at once.
- Entry/exit punches: many in/out per day; show first entry, last exit, number of exits/entries, total WORKED time in h:m:s (breaks excluded); missed exit flagged "incomplete". Feeds hourly/shift salary (Phase 3).
- Salary (Phase 3): daily wage, shift-wise, hourly, fixed, per-lecture, TA/DA, advance, deductions, slips.
- Store & diet: gym supplement store + diet chart (reference old health-diet / store files); school/college stores (book sets, uniform).
- Reminder to owner: before selling, test `firestore.rules` in the Firebase emulator and add App Check / rate limit for the public admission form.

---
# OrgDesk — technical hand-off

## Product
A universal, sellable system for gyms, schools and colleges (more types later). One shared Firebase project; each organisation registers itself in ~10 minutes with `setup.html`; every org type has its own pre-built admission form, documents, fee plans, groups and terms. Static HTML/JS on GitHub Pages + Firebase Auth + Firestore (compat SDK 9.22.2). **No build step. Deploy by uploading files.** UI language: professional English; form labels carry a small Hindi hint.

Owner's working rules: build ONE phase at a time and get approval; no unrequested files; Hinglish chat replies; the old 5 Brother's apps (admission/attendance/pay/health-diet/store) are the "best working" reference for flows and must keep running separately; security matters (XSS-safe, rules strict).

## Files (all in one folder)
| File | Purpose |
|---|---|
| `templates.js` | ALL org-type data: sections/fields per type, document slots, default plans/groups, terms. Add a new org type here only. |
| `form.js` | Step-by-step admission form engine built from a template (`OF.mount`), validation, auto age/BMI, photo upload + camera, signature pad; `OF.sections` = read-only view for admin |
| `core.js` | Firebase init + helpers (`G.*`: dates, esc, img, search `G.match`, image `G.compress`, `G.thumb`) |
| `setup.html` | 5-step wizard: type → details → plans/groups → terms → owner account. Creates `orgs/{id}` + `users/{uid}` |
| `join.html` | Public admission form (`?o=<org>`) |
| `admin.html` + `admin.js` | Owner panel: Home dashboard, Admissions desk (approve/deny), Members (search, renew), Receipts, Settings |
| `receipt.js` | Receipt drawn on canvas → PNG / print / WhatsApp text |
| `card.html` | Member card PWA page (`?o=&m=`): status, validity, notice, "mark attendance" |
| `firestore.rules` | Multi-tenant rules (reviewed by eye only — NOT run in the emulator) |
| `ui.css`, `manifest.json`, `sw.js`, icons, `firebase-config.js` | shared UI / PWA / config |
| `t/` | Playwright e2e (`t/e2e.js`) with an in-memory Firebase stub (`t/stub.js`) |

## Data model (`orgs/{org}`)
- `orgs/{org}`: name, type(gym|school|college), ownerUid, phone, address, logo, color, upiId, plans[{id,name,months,price}], groups[{id,name,time?}], terms, termsVersion, notice, receiptPrefix, codePrefix. Public `get`.
- `members/{id}`: top-level name, phone, kind, status(pending|active|denied), planId/Name/Price/Months, batchId/Name, joinDate, utr, termsVersion, signName, createdAt; after approval code, startDate, expiry, expiryTs, paid, due, approvedDate/By. **All other form answers live in the `data` map** (so new fields need no rule change). Staff-only read.
- `files/{id}`: photo, idFront, idBack, doc1–doc4, sign, idType (base64 JPEGs; keep each ≤ ~110 KB so a doc stays < 1 MB). Staff-only read.
- `cards/{id}`: public-by-random-id: name, code, status, planName, batchName, expiry, expiryTs, thumb, (reason if denied).
- `payments/{id}`: memberId, amount, mode, utr, receiptNo, type(admission|renewal), planName, from, to, date, by, byName.
- `counters/seq`: {member, receipt} — incremented inside a transaction with every approval/payment.
- `attendance/{date_memberId}`: member self-create allowed by rules (card active + not expired, once a day).
- `users/{uid}`: {orgId, role, name} pointer. `staff/{uid}` docs grant staff access (rules ready, UI not built).

## Tested (mock Firebase, Chromium, 400px width) — 67 checks pass
Setup wizard for gym/school/college, duplicate-ID check, full gym admission (gender/marital logic, auto age & BMI, conditions, 5 MB photo compress, camera input, signature), admin search/approve/receipt/renew/deny/terms-version, dashboard collection, member card + attendance + denied + pending states. School and college: form structure and document slots only (not a full submission).

## NOT tested / known gaps
1. `firestore.rules` never run in the emulator — test with `firebase emulators` before selling.
2. Public `members/files` create has no rate limit / App Check → spam possible. Add App Check or a Cloud Function later.
3. Only the owner can sign in; staff accounts (receptionist, trainer) need an "Add staff" flow (create auth user + `staff/{uid}` + role-based tabs).
4. Card attendance is a plain tap (no GPS radius / selfie yet).
5. No edit-member, delete-member, fee-due reminders, partial-payment ledger.
6. Real background push needs a Cloud Function (Blaze plan). Today: install card + in-app `notice`.
7. Images are base64 in Firestore (fine for hundreds of members; move to Firebase Storage if it grows).
8. Real-device camera/capture and iOS PWA install not tried.

## Roadmap (agreed with the owner)
- **Phase 2** — Attendance with several layers, chosen per person (org default + per-person override):
  1. **Selfie + GPS radius** (reference: old `attendance_55.html`) for regular members/students.
  2. **Personal QR** for VIP / senior staff (principal, HOD, directors, office heads) so they do not stand in a selfie queue. QR must carry an unguessable per-person token (NOT the plain member id), be scanned by a gate/kiosk device that is signed in as staff, and allow one mark per day.
  3. **Manual** by admin, batch/class-wise, absent list, calendar view.
  - **ID card (downloadable, small):** name, organisation, post, department, floor, contact, blood group + QR, as image/PDF; fields configurable per org type.
  - **Bulk QR:** one click to download/print every member's or staff member's QR (printable sheet / PDF / zip of images).
  - QR scanning needs a JS decoder (jsQR / html5-qrcode via CDN) because `BarcodeDetector` is missing on iOS Safari.
  - **In/Out punches (owner requirement):** a person can enter and leave several times a day (breaks). Store each punch with a server timestamp (`attendance/{date_personId}` with a `punches` array of `{in, out}` pairs, or a `punches` subcollection). Toggle IN/OUT on each scan/tap. Show first entry, last exit, number of exits/entries, total WORKED time as **h : m : s** (sum of closed in→out pairs only; time between an out and the next in is break and is NOT counted). Missed exit = open pair: flag "incomplete", auto-close at shift end / midnight, let admin correct. This worked-time figure feeds hourly and shift salary in Phase 3.
  - Full dashboard: live present, absent, expiring list, per-batch counts.
- **Phase 3** — Staff: roles per org type (gym: trainer/receptionist/housekeeping; school: principal/teacher PGT-TGT-PRT/clerk/driver…; college: HOD/professor/guest faculty…), staff attendance by shift or hourly, automatic salary (daily wage, shift-wise, hourly, fixed, per-lecture, TA/DA, advance, deductions) and salary slips.
- **Phase 4** — Store & diet: gym supplement store + diet chart from BMI/goal (reference: `health-diet_23.html`, `store*.html`); school/college stores (book sets, uniform) with order approval (UPI/UTR).
- **Phase 5** — School/college depth: class-wise fee heads & dues, student attendance calendar, parent notices, results.
- **Phase 6** — Push notifications (Cloud Function), App Check, staff roles hardening, rules emulator tests.

## How to run the tests
`cd t && NODE_PATH=$(npm root -g) node e2e.js` (needs Playwright + Chromium; serves the folder on :8098; Firebase is replaced by `t/stub.js`).
